# Payment Release Request

Creates Against Order, Stock Order and Payment Reminder messages for the purchase order WhatsApp group.

## Install on a phone
- **Android (Chrome):** open the site link, tap ⋮ → **Install app** (or **Add to Home screen**).
- **iPhone (Safari):** open the site link, tap Share → **Add to Home Screen**.

## Updating the app
1. Upload the new `index.html` (replace the old one).
2. In `sw.js`, change `const VERSION = 'v1';` to `'v2'` (then `'v3'`, and so on).
3. Phones get the update the next time the app is opened with internet (open it twice if needed).

Settings password: 1234

© @pkm_calicut
